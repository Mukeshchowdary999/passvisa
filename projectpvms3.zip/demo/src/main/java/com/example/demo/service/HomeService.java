package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.PassportRenewal;
import com.example.demo.model.User;
import com.example.demo.repositories.HomeRepository;

@Service
public class HomeService {
	@Autowired
	private HomeRepository homeRepository;
	public void saveData(PassportRenewal passport) {
		
		homeRepository.save(passport);
		
		
		
	}
	public void updateData(PassportRenewal passport) {
		PassportRenewal oldpassport= homeRepository.findById(passport.getPassportId()).orElse(passport);
		oldpassport.setBooklettype(passport.getBooklettype());
		oldpassport.setCity(passport.getCity());
		oldpassport.setCountry(passport.getCountry());
		oldpassport.setExpirydate(passport.getExpirydate());
		oldpassport.setIssuedate(passport.getIssuedate());
		oldpassport.setPassportId(passport.getPassportId());
		oldpassport.setReason(passport.getReason());
		oldpassport.setReceivedissuedate(passport.getReceivedissuedate());
		oldpassport.setState(passport.getState());
		oldpassport.setTypeofservice(passport.getTypeofservice());
		oldpassport.setUserid(passport.getUserid());
		homeRepository.save(oldpassport);
		
	}
	public  String generatePassportId(String booklettype)
	{
		Optional<List<PassportRenewal>> passport=homeRepository.getLastPassportId(booklettype);
		
		if(booklettype.equals("30 Pages"))
		{
		
		if(passport.isPresent())
		{
			List<PassportRenewal> passports=passport.get();
			if(passports.isEmpty())
			{
				return "FPS-301000";
				
			}
			int result=0;
			for(PassportRenewal p:passports)
			{
				String val=p.getPassportId();
				String id=val.substring(val.length()-4);
				System.out.println(id);
				
				Integer pass=Integer.valueOf(id);
				if(pass>result)
				{
					result=pass;
				}
			}
			
			
			return "FPS-30"+(result+1);
			
		}
		else
		{
			return "FPS-301000";
			
			
		}
		
	} 
	else 
	{
		if(passport.isPresent())
		{
			List<PassportRenewal> passports=passport.get();
			if(passports.isEmpty())
			{
				return "FPS-601000";
				
			}
			int result=0;
			for(PassportRenewal p:passports)
			{
				String val=p.getPassportId();
				String id=val.substring(val.length()-4);
				Integer pass=Integer.valueOf(id);
				if(pass>result)
				{
					result=pass;
				}
			}
			
			
			return "FPS-60"+(result+1);
			
			
			
		}
		else
		{
			return "FPS-601000";
			
		}
		
	}
}

}
