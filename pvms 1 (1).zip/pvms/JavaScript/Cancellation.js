document.getElementById('visaCancellationForm').addEventListener('submit', function (e) {
    e.preventDefault();

    // Get form values
    var userId = document.getElementById('userId').value;
    var passportNumber = document.getElementById('passportNumber').value;
    var visaNumber = document.getElementById('visaNumber').value;
    var dateOfIssue = document.getElementById('dateOfIssue').value;

    // Perform validation and calculations
    // For simplicity, assume calculations and validation are done server-side

    // Display success message
    alert("Visa cancellation request submitted successfully!");
});