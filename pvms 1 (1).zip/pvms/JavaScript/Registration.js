document.addEventListener('DOMContentLoaded', function () {
    const form = document.getElementById('registration-form');

    form.addEventListener('submit', function (event) {
        event.preventDefault(); // Prevent the default form submission behavior

        // Collect user input values
        const firstName = form.querySelector('#first-name').value;
        const surname = form.querySelector('#surname').value;
        const dob = form.querySelector('#dob').value;
        const email = form.querySelector('#email').value;
        const contactNumber = form.querySelector('#contact-number').value;
        const gender = form.querySelector('#gender').value;
        const occupation = form.querySelector('#occupation').value;
        const applyType = form.querySelector('#apply-type').value;
        const address = form.querySelector('#address').value;
        const qualification = form.querySelector('#qualification').value;
        const hintQuestion = form.querySelector('#hint-question').value;
        const hintAnswer = form.querySelector('#hint-answer').value;

        // Generate user ID (for demonstration, a simple random ID is generated)
        const userId = generateUserId(firstName, surname);

        // Decide citizen type based on date of birth (for demonstration, checking if the year of birth is before 2000)
        const citizenType = getAgeCategory(dob);

        // Display success message
        const successMessage = `Dear ${firstName},\nYour User Id is ${userId} and your password is <password>.\nYou are planning for ${applyType} and your citizen type is ${citizenType}.`;

        alert(successMessage); // Display success message (you can customize this part based on your UI design)

        // Reset the form after successful submission
        form.reset();
    });

    // Function to generate a random user ID (for demonstration purposes)
    function generateUserId(firstName, surname) {
        const randomId = Math.floor(Math.random() * 10000); // Generate a random number
        return `${firstName.toLowerCase()}_${surname.toLowerCase()}_${randomId}`;
    }

    // Function to decide citizen type based on date of birth
    function getAgeCategory(dateOfBirth) {
        const birthYear = new Date(dateOfBirth).getFullYear();
        const currentYear = new Date().getFullYear();
        return birthYear <= 2000 ? 'Adult' : 'Minor';
    }
});