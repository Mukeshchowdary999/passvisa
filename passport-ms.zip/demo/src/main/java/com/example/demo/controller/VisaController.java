package com.example.demo.controller;

import java.sql.Date;
import java.time.LocalDate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.demo.model.Visa;
import com.example.demo.service.VisaService;

import jakarta.servlet.http.HttpSession;

@Controller
public class VisaController {
	
	@Autowired
	VisaService visaService;
	@PostMapping("/applyVisa")
	public String handleApplyVisaData(@RequestParam("userId") String userId,
			   @RequestParam("country") String country,
			   @RequestParam("occupation") String occupation,
			   @RequestParam("dateOfApplication") String dateOfApplication,
			   HttpSession session)
	{
		
		Visa visa=new Visa();
		visa.setUserId(userId);
		visa.setCountry(country);
		visa.setOccupation(occupation);
		String visaId=visaService.generateVisaId(visa);
		visa.setVisaId(visaId);
		double expiryYears=visaService.getExpiryDate(visa);
	
		
		Date applicationDate=Date.valueOf(dateOfApplication);
		LocalDate issue=applicationDate.toLocalDate();
		LocalDate issuedate=issue.plusDays(10);
		Date dateOfIssue=Date.valueOf(issuedate);
		Date dateOfExpiry;
		if(expiryYears==1.5)
		{
			LocalDate expiry=dateOfIssue.toLocalDate();
			LocalDate exp=expiry.plusYears(1).plusMonths(6);
			 dateOfExpiry=Date.valueOf(exp);
		}
		else
		{
		    Integer	ex=(int) expiryYears;
			LocalDate expiry=dateOfIssue.toLocalDate();
			LocalDate exp=expiry.plusYears(ex);	
			 dateOfExpiry=Date.valueOf(exp);
		}
		
		double cost=visaService.calculateRegistrationCost(visa);
		visa.setRegistrationCost(cost);
		visa.setDateOfExpiry(dateOfExpiry);
		
		visa.setDateOfIssue(dateOfIssue);
		visa.setDateOfApplication(applicationDate);
		
		visaService.saveVisaData(visa);
		session.setAttribute("visadetails", visa);
		return "aftervisa";
	}

}
